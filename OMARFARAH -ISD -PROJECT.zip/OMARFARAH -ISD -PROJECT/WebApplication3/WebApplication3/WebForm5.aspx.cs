﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebApplication3
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_Click(object sender, EventArgs e)
        {
             DataSet1TableAdapters.customersTableAdapter da = new DataSet1TableAdapters.customersTableAdapter();
             /* if (da.GetDataBy(TextBox1.Text, TextBox2.Text).ToString().Equals(""))
              {
                  Label3.Text = "Invalid";
              }
              else
              {
                  Label3.Text = "Correct";
                  Session["userid"] = da.GetDataBy(TextBox1.Text, TextBox2.Text);

              }*/

            
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["barbarshopConnectionString"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from customers where email = @username and password = @pass", con);
            cmd.Parameters.AddWithValue("@username", TextBox1.Text);
            cmd.Parameters.AddWithValue("@pass", TextBox2.Text);

            SqlDataReader sdr = cmd.ExecuteReader();

           

            if (sdr.Read())
            {
                Label3.Text = "Login Successful...!";

                Label4.Text ="your ID is : "+ sdr["id"].ToString()+"  Use it to set your appuntment";

            }
            else
            {
                Label3.Text = "Email or Password Incorrect....!";
            
            }
            con.Close();

            

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSet1TableAdapters.bookingTableAdapter da = new DataSet1TableAdapters.bookingTableAdapter();
            da.Insert(int.Parse(TextBox3.Text),TextBox4.Text, TextBox5.Text);
            Label9.Text = "DONE ....WE WAITING FOR YOU .....!";

        }

        protected void Button9_Click(object sender, EventArgs e)
        {



            DataSet1TableAdapters.customersTableAdapter da = new DataSet1TableAdapters.customersTableAdapter();
            da.InsertQuery(TextBox1.Text, TextBox2.Text);
            Label3.Text = "DONE YOU ARE RIGISTERD NOW ....WELCOME IN OUR BABRBER SHOP!";

        }
    }
}